Version 0.2.1 (March 18th 2018)
-----------------------------
 * Added TypeScript Declaration File

Version 0.2.0 (March 17th 2018)
-----------------------------
 * Mouette.js is now static. No instantiation needed. One logger for the entire project. even if dependencies use it. 

Version 0.1.0 (December 24th 2017)
-----------------------------
 * initial version
